# 01 Supermarket Sales Analysis

Power BI supermarket sales analysis report. Pages cover branch/city, product lines, dates, customer segments, payment methods and two summary dashboards.

## Pages identified in source Power BI report
- Branch and city
- Product line insights
- Date and time insights
- customer analysis
- Payment method
- Dashboard1
- Dashboard 2

## Fields and visuals
Source table: Sheet1. Fields referenced include Branch, City, Total, Quantity, Rating, Unit price, Product line, gross income, Date, Customer type, Gender, Payment, Invoice ID and Tax 5%.

## Extraction limitation
The uploaded archive is a Power BI report package. Its report pages and visual field mappings were inspected. This package does not contain separately-exported PBIX projects or raw dataset files, so this folder contains the project summary, not a fully independent editable report.
