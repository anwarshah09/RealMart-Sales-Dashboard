# 02 Amazon Sales Analysis

Amazon sales analysis page within the Power BI report.

## Pages identified in source Power BI report
- amazone

## Fields and visuals
Table: Amazon sales dataset. Fields referenced include Segment, Sales, Profit, Sub-Category, Discount %, Order Date, Category, State, Region, City, Shipment Cost and Quantity.

## Extraction limitation
The uploaded archive is a Power BI report package. Its report pages and visual field mappings were inspected. This package does not contain separately-exported PBIX projects or raw dataset files, so this folder contains the project summary, not a fully independent editable report.
