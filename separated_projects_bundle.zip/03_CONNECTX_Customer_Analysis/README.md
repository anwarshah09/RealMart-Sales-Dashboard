# 03 CONNECTX Customer Analysis

ConnectX customer/telecom analytics page, likely focused on customer status and retention-related measures.

## Pages identified in source Power BI report
- CONNECTX

## Fields and visuals
Table: ConnectX. Fields referenced include Contract, Customer ID, Gender, Age, Customer Status, Payment Method, Tenure in Months, Total Charges, Total Revenue and Avg Monthly GB Download.

## Extraction limitation
The uploaded archive is a Power BI report package. Its report pages and visual field mappings were inspected. This package does not contain separately-exported PBIX projects or raw dataset files, so this folder contains the project summary, not a fully independent editable report.
